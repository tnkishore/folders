CREATE TABLE gcrm.fact_camp_events2 (
              new_campaign_disp_name varchar(100) NULL,
              new_camp_id varchar(20) NULL,
              vin varchar(100) NULL,
              channel_clubbed varchar(20) NULL,
              asset_id varchar(15) NULL,
              contact_id varchar(15) NULL,
              prog_start_dt_new timestamp NULL,
              prog_end_dt_new timestamp NULL,
              total_ro_amount numeric NULL,
              ro_count int8 NULL,
              bin_ro int4 NULL,
              ind_rr int4 NULL,
              ind_ps int4 NULL,
              ind_fs int4 NULL,
              rr_count int8 NULL,
              ps_count int8 NULL,
              fs_count int8 NULL,
              con_cd varchar(30) NULL,
              sex_mf varchar(30) NULL,
              city_code varchar(50) NULL,
              campaign_type varchar(20) NULL,
              model_cd varchar(30) NULL
);

copy gcrm.fact_camp_events2 from 'D:/Hyundai/Gowdaman/sms12_5/sms12_5.csv' delimiter ',' quote '"' csv header;
copy gcrm.fact_camp_events2 from 'D:/Hyundai/Gowdaman/fact_camp_events2/fact_camp_events2_2.csv' delimiter ',' quote '"' csv ;
copy gcrm.fact_camp_events2 from 'D:/Hyundai/Gowdaman/fact_camp_events2/fact_camp_events2_3.csv' delimiter ',' quote '"' csv ;
copy gcrm.fact_camp_events2 from 'D:/Hyundai/Gowdaman/fact_camp_events2/fact_camp_events2_4.csv' delimiter ',' quote '"' csv ;
copy gcrm.fact_camp_events2 from 'D:/Hyundai/Gowdaman/fact_camp_events2/fact_camp_events2_5.csv' delimiter ',' quote '"' csv ;
copy gcrm.fact_camp_events2 from 'D:/Hyundai/Gowdaman/fact_camp_events2/fact_camp_events2_6.csv' delimiter ',' quote '"' csv ;
vacuum full gcrm.fact_camp_events2;
--count of rows 32,568,921  23,523,217
select distinct new_camp_id from gcrm.fact_camp_events2;
select * from gcrm.fact_camp_events2 where total_ro_amount is not null;

create table gcrm.fact_camp_events3
as 
select a.*,b.send_dt,b.click_dt,b.open_dt 
from gcrm.fact_camp_events2 as a 
left outer join gcrm.fact_camp_events_log2 as b 
on b.new_camp_id= a.new_camp_id
   and b.contact_id = a.contact_id
  and b.vin=a.vin;--47,867,918
  
  create table gcrm.fact_camp_events4
as 
select a.*,b.send_dt,b.click_dt,b.open_dt 
from gcrm.fact_camp_events2 as a 
left outer join gcrm.fact_camp_events_log2 as b 
on b.new_camp_id= a.new_camp_id
   and b.contact_id = a.contact_id
  ;
select count(*) from  (
select new_camp_id, contact_id,vin, count(*) from gcrm.fact_camp_events3
group by 1,2,3
having count(*) >1 ) as b;
where new_camp_id='SMS12';
vacuum analyse gcrm.fact_camp_events2 (new_camp_id, contact_id,vin);

select count(*) from fact_camp_events2;







