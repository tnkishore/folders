-----EMAIL CAMPAIGN 22/11/2019(AFTER DELHI_DEMO)---------------
-- DROP TABLE public.g3_ocmv_exclutionlist;


CREATE TABLE g3_ocmv_exclutionlist (
	contact_id varchar(15) NULL
);
--22937 rows
----count 11876525------------------------------------
create table gcrm.EMAIL_fact_table_RO as 
select distinct a.row_id , a.src_id , a.asset_id 
from  a_camp_con_14_prsp_con_contact_end a
where src_id in (
'1-QAA78U',
'1-1F2I7QH',
'1-17OVJ5H',
'1-VYE9WV',
'1-RUISW7',
'1-ANFRFX',
'1-P3CLPH',
'1-HH7IWN');
-----count 11434173
create table gcrm.EMAIL_fact_table_RO_1  as
select * from gcrm.EMAIL_fact_table_RO
where row_id not in ( select * from ndms.g3_ocmv_exclutionlist);

select src_id, count(*)
from gcrm.EMAIL_fact_table_RO_1 
group by 1;

------------count 11,434,173
create table gcrm.email_fact_table_RO_2  
as
select  distinct 
 src.row_id as camp_id,camp.row_id as contact_id,
 veh.asset_num as vin,
 camp.asset_id,
 date(src.prog_start_dt) as prog_start_dt,
 date(src.prog_end_dt) as prog_end_dt,
 src."name" as camp_name,
 (case
		when src.prog_start_dt is not null then 'EMAIL'
	end )as channel_name
from  gcrm.email_fact_table_RO_1 as camp 
left outer join
s_src as src on src.row_id = camp.src_id 
left outer join
 s_asset as veh on veh.row_id =  camp.asset_id;

------*******************----------------------
-------RO VALUE adduing work type----
--count 18,182,007 ----------

create table ndms.rcrepm_tb_dedup_2_wt
as
select d.*,b.repm_work_type from ndms.rcrepm_tb_dedup_2 as d
 left outer join ndms.ro_three_years_data as b
 on b.repm_ro_no = d.repm_ro_no
    and b.repm_vin = d.repm_vin
    and b.repm_ro_dtime = d.repm_ro_dtime;
---------FIltering total sales amount less than 500000 and removing null values -----------------------
----------count 18,179,727
create table ndms.rcrepm_tb_dedup_2_wt1
as
  select * from ndms.rcrepm_tb_dedup_2_wt    
where total_sales_amount<=500000 and total_sales_amount>=0 ;

select * from ndms.rcrepm_tb_dedup_2;
------------------count 11,686,364   11695951
drop table gcrm.email_fact_table_RO_3;
commit;
 create table gcrm.email_fact_table_RO_3  as
select
	distinct 
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.asset_id,
	mi.camp_name,
	mi.channel_name,
	mi.prog_start_dt,
	mi.prog_end_dt,
	up1.repm_dlr_no,
	count(up1.repm_ro_no) as ro_count,
	(case
		when count(up1.repm_ro_no) > 0 then '1'
		when count(up1.repm_ro_no) = 0 then '0'
	end ) as bin_ro,
	 up1.total_sales_amount,up1.repm_work_type
	 from
	gcrm.email_fact_table_RO_2  as mi
left outer join ndms.rcrepm_tb_dedup_2_wt1 as up1 on
	 up1.repm_vin =mi.vin 
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt
group by
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.channel_name,
	mi.asset_id,
	mi.camp_name,
	mi.prog_start_dt,
	mi.prog_end_dt,
	up1.repm_dlr_no,
   up1.total_sales_amount,up1.repm_work_type;
 
  -----------Removing  duplicates at delar level and removing totla_ro_amount from group by condition from above table
 ---- and filtering worktype as RR,FS,PR--------------------
------------count 1,458,201 ---1,394,119
drop table gcrm.Email_fact_table_RO_4;
commit;
create table gcrm.Email_fact_table_RO_4
as
select
	distinct 
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.asset_id,
	mi.camp_name,
	mi.channel_name,
	mi.prog_start_dt,
	mi.prog_end_dt,
	count(up1.repm_ro_no) as ro_count,
	(case
		when count(up1.repm_ro_no) > 0 then '1'
		when count(up1.repm_ro_no) = 0 then '0'
	end ) as bin_ro,
	sum( up1.total_sales_amount) as total_ro_amt
		 from
	gcrm.email_fact_table_RO_2 as mi
left outer join ndms.rcrepm_tb_dedup_2_wt1 as up1 on
	mi.vin = up1.repm_vin
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt	
	where up1.repm_work_type in ('RR','FS','PS')
group by
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.channel_name,
	mi.asset_id,
	mi.camp_name,
	mi.prog_start_dt,
	mi.prog_end_dt
  ;
 
 -- Checks
 --count always shuld be zero
select count(*) from  (
select camp_id, contact_id,vin, count(*) from gcrm.Email_fact_table_RO_4 
group by 1,2,3
having count(*) >1 ) as b;
---count 6,239
select count(*) from (select camp_id, contact_id, count(*) from gcrm.Email_fact_table_RO_4 
group by 1,2
having count(*) >1 ) as b
order by count desc;

 
 
select b.camp_id, b.contact_id,b.vin,b.repm_work_type from gcrm.Email_fact_table_RO_4 as b 
 inner join (
select camp_id, contact_id,vin,  count(*) from gcrm.Email_fact_table_RO_4 
group by 1,2,3
having count(*) >1 
) as a
on  a.camp_id = b.camp_id and a.contact_id = b.contact_id and a.vin  = b.vin
order by b.contact_id;


select camp_id, contact_id, count(*) from gcrm.Email_fact_table_RO_4 
group by 1,2
having count(*) >1 ;
select count(contact_id) from ndms.ro_dimension_email_17;



   select distinct camp_id,camp_name,count(*) from gcrm.Email_fact_table_RO_4
   group by camp_id,camp_name;
  
  select distinct bin_ro from gcrm.Email_fact_table_RO_4

