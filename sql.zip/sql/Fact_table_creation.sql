--------------------------------------------------------------------------------------
---- Creating the Fact table - RO count and value --------------------------
-------------------------------------------------------------------------------------------
--12636496
 
create table gcrm.fact_table_RO as 
select distinct a.row_id , a.src_id , a.asset_id 
from  a_camp_con_14_prsp_con_contact_end a
where src_id in ('1-QAA78U'
,'1-1F2I7QH'
,'1-17OVJ5H'
,'1-1EDYJB6'
,'1-1FGSQR5'
,'1-1FZ04OB'
,'1-VYE9WV'
,'1-RUISW7'
,'1-ANFRFX'
,'1-P3CLPH'
,'1-G5QMCP'
,'1-U7XQH9'
,'1-154L44P'
,'1-HLQOFL'
,'1-AXH9AX'
,'1-T1YOOF'
,'1-HH7IWN');

--12266232
create table gcrm.fact_table_SMS_RO_1  as
select * from gcrm.fact_table_RO
where row_id not in ( select * from ndms.ocmv_exclutionlist);

select src_id, count(*)
from gcrm.fact_table_RO_1 
group by 1;
drop table fact_table_RO_2;
commit;
-----12,266,232
create table gcrm.fact_table_RO_2  
as
select  distinct 
 src.row_id as camp_id,camp.row_id as contact_id,
 veh.asset_num as vin,
 camp.asset_id,
 date(src.prog_start_dt) as prog_start_dt,
 date(src.prog_end_dt) as prog_end_dt,
 src."name" as camp_name,
 (case
		when src.prog_start_dt is not null then 'EMAIL'
	end )as channel_name
from  gcrm.fact_table_RO_1 as camp 
left outer join
s_src as src on src.row_id = camp.src_id 
left outer join
 s_asset as veh on veh.row_id =  camp.asset_id;
 
 -- Ro table clean up - remove -ve total and capping for outliers by 99th percentile value which is 47000 INR
---- count 18182007
create table ndms.rcrepm_tb_dedup_2 as 
select a.repm_ro_no,a.repm_ro_dtime,a.repm_dlr_no,a.repm_vin,
sum(a.repm_bill_total_labr_amt + a.repm_bill_total_othr_amt + a.repm_bill_total_part_amt) as total_sales_amount
from ndms.rcrepm_tb_dedup as a
group by a.repm_ro_no,a.repm_ro_dtime,a.repm_dlr_no,a.repm_vin;
--------Removing negative values ---------------------
--  count 18181068
create table ndms.rcrepm_tb_dedup_3
as select a.*,
   (case when total_sales_amount>47000 then 47000
        when total_sales_amount<= 47000 then total_sales_amount end) as Total_RO_amt
   from ndms.rcrepm_tb_dedup_2 as a
  where total_sales_amount >=0;
 
 -- count 12534759
 
 create table gcrm.fact_table_RO_3  as
select
	distinct 
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.asset_id,
	mi.camp_name,
	mi.channel_name,
	mi.prog_start_dt,
	mi.prog_end_dt,
	up1.repm_dlr_no,
	count(up1.repm_ro_no) as ro_count,
	(case
		when count(up1.repm_ro_no) > 0 then '1'
		when count(up1.repm_ro_no) = 0 then '0'
	end ) as bin_ro,
	 up1.Total_RO_amt
	 from
	fact_table_RO_2 as mi
left outer join ndms.rcrepm_tb_dedup_3 as up1 on
	mi.vin = up1.repm_vin
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt
group by
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.channel_name,
	mi.asset_id,
	mi.camp_name,
	mi.prog_start_dt,
	mi.prog_end_dt,
	up1.repm_dlr_no,
   up1.Total_RO_amt;
-----------Removing  duplicates at delar level and removing totla_ro_amount from group by condition fromabove table--------------------
  12,534,759     12,321,503; 12,266,232
drop table gcrm.fact_table_RO_4_suresh;
commit;
create table gcrm.fact_table_RO_4_suresh
as
select
	distinct 
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.asset_id,
	mi.camp_name,
	mi.channel_name,
	mi.prog_start_dt,
	mi.prog_end_dt,
	count(up1.repm_ro_no) as ro_count,
	(case
		when count(up1.repm_ro_no) > 0 then '1'
		when count(up1.repm_ro_no) = 0 then '0'
	end ) as bin_ro,
	sum( up1.Total_RO_amt) as total_ro_amt
	 from
	fact_table_RO_2 as mi
left outer join ndms.rcrepm_tb_dedup_3 as up1 on
	mi.vin = up1.repm_vin
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt
group by
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.channel_name,
	mi.asset_id,
	mi.camp_name,
	mi.prog_start_dt,
	mi.prog_end_dt	
  ;

