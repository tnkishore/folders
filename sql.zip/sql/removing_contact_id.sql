
--------Removing contact_id and duplicates from email fact table --------------------------
--count 12,266,232 1,827,651
create table gcrm.fact_table_RO_4_suresh_bkp
as
select * from gcrm.fact_table_RO_4_suresh;
--------------removing contact_id
alter table gcrm.fact_table_RO_4_suresh_bkp
drop column contact_id;
commit;

select count(*) from fact_table_RO_4_suresh_bkp where camp_id='1-AXH9AX';;

---removing 1_AXH9AX campaign out 17 from fat table
--count 8434
delete from fact_table_RO_4_suresh_bkp
where camp_id='1-AXH9AX';
commit;
--removing duplicates 
--fetching records
--count 1827651
create table fact_table_RO_4_suresh_bkp2
as
select *,count(*) from fact_table_RO_4_suresh_bkp
group by camp_id,vin,asset_id,camp_name,channel_name,prog_start_dt,prog_end_dt,ro_count,bin_ro,total_ro_amt
having count(*)>1;

select * from fact_table_RO_4_suresh_bkp2;
--- removing duplicates 
create table ro_value_unique
as
select distinct * from fact_table_RO_4_suresh_bkp;

vacuum full ro_value_unique;