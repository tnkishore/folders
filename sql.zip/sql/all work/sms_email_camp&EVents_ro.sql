---11,450,727
create table gcrm.email_camp_events_allRO
as
select
	mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt,
	up1.repm_ro_dtime,
	(up1.total_sales_amount) as total_sales_amount,
	 up1.repm_work_type,
	 up1.repm_ro_no,
	 up1.repm_dlr_no
	 from
	gcrm.email_camp_events_2  as mi
left outer join ndms.rcrepm_tb_dedup_2_wt1 as up1 on
	up1.repm_vin = mi.vin
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt
	;

drop table sms_camp_events_allRO;
commit;
----------count 22,846,128	
create table gcrm.sms_camp_events_allRO
as
select
	mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt,
	up1.repm_ro_dtime,
	(up1.total_sales_amount) as total_sales_amount,
	 up1.repm_work_type,
	 up1.repm_ro_no,
	 up1.repm_dlr_no
	 from
	gcrm.sms_camp_events_2  as mi
left outer join ndms.rcrepm_tb_dedup_2_wt1 as up1 on
	up1.repm_vin = mi.vin
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt
	;
---22,635,090
create table  gcrm.sms_camp_events_allRO_1 as select
	distinct 
	mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt,
	sum (total_sales_amount) as total_sales_amount,
	count(repm_ro_no) as ro_count,
	(case
		when count(mi.repm_ro_no) > 0 then 1
		when count(mi.repm_ro_no) <= 0 then 0
	end ) as bin_ro
from gcrm.sms_camp_events_allRO as mi
group by 
 mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt;

  select camp_id, camp_name_for_disp, count(contact_id), sum(bin_ro) from sms_camp_events_allRO_1
    group by 1,2 ;  

insert into gcrm.camp_events_allRO
select * from gcrm.email_camp_events_allRO;

---count 32,575,898
select count(*) from gcrm.camp_events_allRO;

select count(*), count(distinct contact_id), count(distinct VIN), count(distinct repm_dlr_no),
count(distinct repm_ro_no)  from  gcrm.camp_events_allRO;


select distinct repm_dlr_no
from gcrm.camp_events_allRO;

select distinct campaign_name from OUR_SRC as os
where campaign_type='Camps & Events' and channel='SMS';

select distinct sms_campaign_name from sms_contacts_4 as sce;

select * from OUR_SRC where campaign_name='WomensDaySMS_March18';

update OUR_SRC 
set campaign_name='Women�sDaySMS_March18'
where CAMP_ID='SMS38' and CHANNEL='SMS' AND camp_sub_cat='Special Day';
commit;
