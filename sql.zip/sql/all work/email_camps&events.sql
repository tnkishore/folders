----------8 capaigns from campaignlist v0.5 provided by Gowdhaman campaign type CAMP& EVENTS
---count 11,876,525
create table EMAIL_camp_events
as
select distinct
	o.campaign_name,
	o.camp_id,
	o.channel,
	date(o.prog_start_dt) as prog_start_dt,
	date(o.prog_end_dt) as prog_end_dt,	
	sc.asset_id,
	o.camp_name_for_disp,
	sc.row_id as contact_id
from
	a_camp_con_14_prsp_con_contact_end as sc
left outer join our_src as o on
	o.camp_id = sc.src_id
	where o.campaign_type='Camps & Events' and o.channel='EMAIL';

-- Checks 
select count(distinct camp_id), count(distinct contact_id), count(*) from EMAIL_camp_events;

---fetching vin numbers for EMAIL CAMPAIGNS by using s_asset table
--count  11,876,525
create table EMAIL_camp_events_1
as 
select distinct
	a.campaign_name,
	a.camp_id,
	b.asset_num as vin,
	a.channel,
	a.asset_id,
	a.camp_name_for_disp,
	a.contact_id,	
	a.prog_start_dt,
	a.prog_end_dt	
	from EMAIL_camp_events as a 
left outer join s_asset as b 
	on b.row_id = a.asset_id;
	
--Applying exclutionlist for removing contacts with more than 3 vin's
---count 11,434,173
create table email_camp_events_2
as
select * from gcrm.email_camp_events_1
where contact_id not in ( select * from ndms.g3_ocmv_exclutionlist);

vacuum full email_camp_events_2;

-----count 2,62,917
select count(*) from email_camp_events_2 where vin is null;

---removing  records which is having vin nulls 
delete from email_camp_events_2 where vin is null;
commit;
--count 11,171,256
select count (*) from email_camp_events_2;


drop table email_camp_events_3;
commit;

--- Getting the RO details for the campaign duration only for mechanical ROs
---count 11,289,213
select count(*) from gcrm.email_camp_events_3;

create table gcrm.email_camp_events_3
as
select
	mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt,
	up1.repm_ro_dtime,
	(up1.total_sales_amount) as total_sales_amount,
	 up1.repm_work_type,
	 up1.repm_ro_no,
	 up1.repm_dlr_no
	 from
	gcrm.email_camp_events_2  as mi
left outer join ndms.rcrepm_tb_dedup_2_wt1 as up1 on
	up1.repm_vin = mi.vin
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt
	where  up1.repm_work_type in ('RR','FS','PS')	
;

-- Checks 
select repm_work_type , count(*) from ndms.rcrepm_tb_dedup_2_wt1 group by 1;

--
drop table gcrm.email_camp_events_4;

-- Roll up for a campid, contact, VIN the RO details 
-- 11,171,256
create table  gcrm.email_camp_events_4 as select
	distinct 
	mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt,
	sum (total_sales_amount) as total_sales_amount,
	count(repm_ro_no) as ro_count,
	(case
		when count(mi.repm_ro_no) > 0 then 1
		when count(mi.repm_ro_no) <= 0 then 0
	end ) as bin_ro
from gcrm.email_camp_events_3 as mi
group by 
 mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt;
 select * from  gcrm.email_camp_events_3; 

--- Checks

  select ro_count, count(*) from gcrm.email_camp_events_4 group by 1;
    select camp_id, camp_name_for_disp, count(contact_id), sum(bin_ro) from email_camp_events_4
    group by 1,2 ;   
   
 --count always shuld be zero
select count(*) from  (
select camp_id, contact_id,vin, count(*) from gcrm.email_camp_events_4
group by 1,2,3
having count(*) >1 ) as b;
---count 4,67,683
select count(*) from (select camp_id, contact_id, count(*) from gcrm.email_camp_events_4 
group by 1,2
having count(*) >1 ) as b
order by count desc;


