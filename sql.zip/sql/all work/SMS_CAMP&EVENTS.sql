---------- capaigns from campaignlist v0.5 provided by Gowdhaman campaign type CAMP& EVENTS and channel ='SMS'
select * from sms_camp_events;
select count(*) from sms_contacts_4;--65,387,315
--create table for sms camp&Events 
--count 32,503,319
drop table sms_camp_events;
commit;
vacuum full sms_contacts_4;
vacuum full our_src;
create table sms_camp_events
as
select distinct
	o.campaign_name,
	o.camp_id,
	o.channel,
	date(o.prog_start_dt) as prog_start_dt,
	date(o.prog_end_dt) as prog_end_dt,	
	sc.asset_id,
	o.camp_name_for_disp,
	sc.per_id as contact_id
from
	sms_contacts_4 as sc
left outer join our_src as o on
	o.campaign_name = sc.sms_campaign_name
	where o.campaign_type='Camps & Events' and o.channel='SMS';
vacuum full sms_camp_events;
---fetching vin numbers from s_asset table using asset_id
--count 32,503,319
create table sms_camp_events_1
as 
select distinct
	a.campaign_name,
	a.camp_id,
	b.asset_num as vin,
	a.channel,
	a.asset_id,
	a.camp_name_for_disp,
	a.contact_id,	
	a.prog_start_dt,
	a.prog_end_dt	
	from sms_camp_events as a 
left outer join s_asset as b 
	on b.row_id = a.asset_id;

---Applying exclutionlist for removing contacts with more than 3 vin's
---count 31,312,612
drop table SMS_camp_events_2;
commit;
create table SMS_camp_events_2
as
select * from gcrm.SMS_camp_events_1
where contact_id not in ( select * from ndms.g3_ocmv_exclutionlist);

-----count 8,677,522
select count(*) from sms_camp_events_2 where vin is null;

---removing  records which is having vin nulls 
delete from sms_camp_events_2 where vin is null;
commit;
--count 22,635,090
select count (*) from sms_camp_events_2;
-- ndms.rcrepm_tb_dedup_2_wt1is contains theree years ro data
select * from ndms.rcrepm_tb_dedup_2_wt1;


drop table gcrm.sms_camp_events_3;
commit;
--- Getting the RO details for the campaign duration only for mechanical ROs
---count  22,723,394
create table gcrm.sms_camp_events_3
as
select
	mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt,
	up1.repm_ro_dtime,
	(up1.total_sales_amount) as total_sales_amount,
	 up1.repm_work_type,
	 up1.repm_ro_no,
	 up1.repm_dlr_no
	 from
	gcrm.sms_camp_events_2  as mi
left outer join ndms.rcrepm_tb_dedup_2_wt1 as up1 on
	up1.repm_vin = mi.vin
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt
	and up1.repm_work_type in ('RR','FS','PS')	
;

drop table gcrm.sms_camp_events_4;
commit;

-- Roll up for a campid, contact, VIN the RO details 
-- 22,635,090
create table  gcrm.sms_camp_events_4 as select
	distinct 
	mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt,
	sum (total_sales_amount) as total_sales_amount,
	count(repm_ro_no) as ro_count,
	(case
		when count(mi.repm_ro_no) > 0 then 1
		when count(mi.repm_ro_no) <= 0 then 0
	end ) as bin_ro
from gcrm.sms_camp_events_3 as mi
group by 
 mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt;
	
     -- Checks
	 
	 select ro_count, count(*) from gcrm.sms_camp_events_4 group by 1;
    select camp_id, camp_name_for_disp, count(contact_id), sum(bin_ro) from sms_camp_events_4
    group by 1,2 ;
 --count always shuld be zero
select count(*) from  (
select camp_id, contact_id,vin, count(*) from gcrm.sms_camp_events_4 
group by 1,2,3
having count(*) >1 ) as b;
---count 9,68,644
select count(*) from (select camp_id, contact_id, count(*) from gcrm.sms_camp_events_4 
group by 1,2
having count(*) >1 ) as b
order by count desc;

insert into camp_events_1
select * from gcrm.email_camp_events_4;

select distinct vin from camp_events_1;
-----below table created for dashboard creation in qlick sense with merging data from both sms and email and taking source as contact_mster table 
create table all_camp_events_2
as
select  distinct
mi.campaign_name,
	mi.camp_id,
	mi.vin,
	mi.channel,
	mi.asset_id,
	mi.camp_name_for_disp,
	mi.contact_id,	
	mi.prog_start_dt,
	mi.prog_end_dt,
	mi.total_sales_amount,
	mi.ro_count,
	 mi.bin_ro,
	b.sex_mf ,
    b.city ,
    b.con_city_name ,
    b.con_state ,
    b.con_region ,
    b.con_zone	 
	 from all_camp_events as mi 
	 inner join contact_analysis_master_2 as b 
	 on b.contact_id = mi.contact_id;
	
	
	 vacuum  full all_camp_events_2;
	 select count( distinct contact_id) from all_camp_events_2;