call  test_phone();
create or replace procedure test_phone ()
LANGUAGE plpgsql
As $$
declare 
c_detail cursor  for 
select * from gcrm.cust_seg_temp1 a where phone is not null and email is not null limit  1;
v_asset_num   "gcrm"."cust_seg_temp1"."asset_num"%type;
v_asset_id      "gcrm"."cust_seg_temp1"."asset_id"%type;
v_contact_id       "gcrm"."cust_seg_temp1"."contact_id"%type;
V_phone       "gcrm"."cust_seg_temp1"."phone"%type;
V_email       "gcrm"."cust_seg_temp1"."email"%type;
begin	
  open c_detail;
    fetch c_detail into v_asset_num,v_asset_id,v_contact_id,V_phone ,V_email;
   insert into  TEST_PH1
       VALUES (v_asset_num,v_asset_id,v_contact_id,V_phone ,V_email);                
        --  create sequence group_id start 1;     
       insert into  TEST_PH12 
           select asset_num as v_vin,asset_id as v_asset_id,contact_id as v_contact_id,
               phone as v_phone ,email as v_email from   gcrm.cust_seg_temp1 as c
                inner join TEST_PH1 as b 
                on   c.asset_num =b.v_vin
                or b.V_phone =c.phone 
                or b.V_email = c.email;               
    delete from gcrm.cust_seg_temp1 where (asset_num) in (select v_vin from  TEST_PH1);
    --delete from gcrm.cust_seg_temp1 where phone in (select v_phone from TEST_PH1) ;
   --delete from gcrm.cust_seg_temp1 where email in ((select v_email from TEST_PH1);       
END ;
$$;

