select * from a_camp_con_14_prsp_con_contact_end;--22358944
select * from our_src where campaign_type='EW Promotion';
-- 
-- Step 1  - SRC file get EW promotion ids
-- Step 2 - get relevant data from Email camps data
-- Step3 - get relevant data from SMS camps data
-- Step 4 - append above 2 tables 
-- remove contacts with no VIN
---- apply exclusion list on contact id
-- Exclusion list on VINs
-- prepare the Warranty table REg date -JAn2017 - Jun2019 and amount > 500
--- Dealer wise if repetition -  then perform same step by taking by contaid, campid, VIN, max reg date 
-- join the 2 tables 
---count 86577-----------------------------------
create table extended_warnty_1
as
select * from a_camp_con_14_prsp_con_contact_end as a
 left outer join our_src as b
  on b.camp_id = a.src_id
where  b.campaign_type='EW Promotion'
;
---count 73227
create table extended_warnty_2
as
select  distinct 
 camp.camp_id,
 camp.row_id as contact_id,
 veh.asset_num as vin,
 camp.asset_id,
 date(camp.prog_start_dt) as prog_start_dt,
 date(camp.prog_end_dt) as prog_end_dt,
 camp.campaign_name as camp_name,
 camp.channel as channel_name
 from  gcrm.extended_warnty_1 as camp 
left outer join
 s_asset as veh on veh.row_id =  camp.asset_id;
----count 69819
create table gcrm.extended_warnty_3  as
select * from gcrm.extended_warnty_2
where contact_id not in ( select * from ndms.g3_ocmv_exclutionlist);

----1,923,916
create table extended_warnty_4
as
select * from sms_contacts_4  as a
 left outer join our_src as b
  on b.campaign_name = a.sms_campaign_name
where  b.campaign_type='EW Promotion'
;
--1,501,616
create table gcrm.extended_warnty_5
as
select distinct 
    sc.camp_id,
	sc.per_id as contact_id,
	veh.asset_num as vin,
	sc.asset_id,	
	date (sc.prog_start_dt) as prog_start_dt,
	date(sc.prog_end_dt) as prog_end_dt,
	sc.campaign_name as camp_name,
	sc.channel as channel_name	
from
	extended_warnty_4 as sc
left outer join s_asset as veh on
	veh.row_id = sc.asset_id;

drop table extended_warnty_6;
commit;
---1,290,612
create table gcrm.extended_warnty_6  as
select * from gcrm.extended_warnty_5
where contact_id not in ( select * from ndms.g3_ocmv_exclutionlist);
--------removing vin nulls ----------------
--sms campaign count 9,78,669
create table extended_warnty_7
as 
select * from extended_warnty_6
where vin is not null;
--email campaign 50447
create table extended_warnty_8
as 
select * from extended_warnty_3 
where vin is not null;

--------appending data from both email and sms campaigns-----
---count 9,78,669
create table extended_warnty_9
as 
select * from extended_warnty_7;
--50447
insert into extended_warnty_9
select * from extended_warnty_8;
--1,029,116
select count(*) from extended_warnty_9;

-----Extended warranty table  with 2017 to 2019 june and >500 warranty amount-------------------------
 create table extended_warranty_threeyears_data
 as
select * from ndms.ser_rgextb_tb
where extract( year from date(extb_reg_date))>=2017 and extract ( year from date(extb_reg_date))<=2019;

 create table extended_warranty_threeyears_data_amt
 as
select *  from extended_warranty_threeyears_data
where extb_wrnty_amt >500;

drop table extended_warnty_10;
commit;

---1,034,373
create table extended_warnty_10
as 
  select distinct 
    sc.camp_id,
	sc.contact_id,
	sc.vin,
	sc.asset_id,	
	sc.prog_start_dt,
	sc.prog_end_dt,
	sc.camp_name,
	sc.channel_name,
	sum (am.extb_wrnty_amt) as Total_extb_wrnty_amnt,
	am.extb_dlr_no,
	am.extb_wrnty_no,
	date(am.extb_reg_date) as extb_reg_date
	from extended_warnty_9	as sc 
	left outer join extended_warranty_threeyears_data_amt as am
	on  am.extb_vin = sc.vin
group by 
sc.camp_id,
	sc.contact_id,
	sc.vin,
	sc.asset_id,	
	sc.prog_start_dt,
	sc.prog_end_dt,
	sc.camp_name,
	sc.channel_name,
   am.extb_reg_date,
  am.extb_dlr_no,
	am.extb_wrnty_no;
	select * from extended_warranty_threeyears_data_amt;
	

-----fetching maximum extb_reg_date to avoid duplicates -------
--95,831
drop table max_extb_warnty_details;
commit;
create table max_extb_warnty_details
as
select 
	camp_id,
	contact_id,
	vin,
	max (extb_reg_date)	as max_extb_reg_date,
	sum(Total_extb_wrnty_amnt) as Total_extb_wrnty_amnt
	from extended_warnty_10
	where vin is not null and extb_reg_date is not null 
	group by camp_id,
	contact_id,
	vin;
	----------------------------------------------
--95,831
---removing duplicate records 
drop table extended_warnty_11;
commit;
create table extended_warnty_11
as 
  select distinct 
    sc.camp_id,
	sc.contact_id,
	sc.vin,
	sc.asset_id,	
	sc.prog_start_dt,
	sc.prog_end_dt,
	sc.camp_name,
	sc.channel_name,
	am.Total_extb_wrnty_amnt,	
	date(sc.extb_reg_date) as extb_reg_date
	from extended_warnty_10	as sc 
	inner join max_extb_warnty_details as am
	on  am.vin = sc.vin
	and am.max_extb_reg_date = sc.extb_reg_date
and am.camp_id= sc.camp_id
and am.contact_id = sc.contact_id;


 --count always shuld be zero
select count(*) from  (
select camp_id, contact_id,vin, count(*) from gcrm.extended_warnty_11
group by 1,2,3
having count(*) >1 ) as b;
---count 541
select count(*) from (select camp_id, contact_id, count(*) from gcrm.extended_warnty_11 
group by 1,2
having count(*) >1 ) as b
order by count desc;


select distinct camp_name,count(*) from extended_warnty_11 group by 1;