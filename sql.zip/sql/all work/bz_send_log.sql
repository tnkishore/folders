--used ta bles bz_send_log,bz_resp_log,bz_link_log
---it contains theree years data from 2017 jan 1st to 2019 june 30th gcrm.bz_send_log_filter_data
--creating table with maximum send_dt
---count 104,090,684
create table bz_send_log_filter_data_maxdt
as
select msg_id,mem_seq,max(send_dt) as max_dt from bz_send_log_filter_data
group by 1,2;

--fetching only latest records 
--count 104,090,684
create table gcrm.bz_send_log_filter_data_maxdt1
as 
select a.*  from gcrm.bz_send_log_filter_data as a 
inner join gcrm.bz_send_log_filter_data_maxdt as b 
on b.msg_id = a.msg_id
and b.mem_seq = a.mem_seq
and b.max_dt =a.send_dt;

select* from gcrm.bz_send_log_filter_data_maxdt1
where msg_id='1_10DS2X0' and mem_seq=1919;

----creating table by using open_dt,click date from resp_log,bz_link_log and fecthing success mail data
---filtering data for sucess mails 
--76617762
create table gcrm.bz_send_log_filter_data_maxdt2
as
select snd.*, resp.open_dt, link.click_dt from gcrm.bz_send_log_filter_data_maxdt1 as snd  
 left join gcrm.bz_resp_log as resp
 on resp.MSG_ID = snd.msg_id
 and resp.mem_seq = snd.mem_seq
 left join (select msg_id, mem_seq, min(click_dt) as click_dt from gcrm.bz_link_log group by msg_id, mem_seq) as link
on link.msg_id=snd.msg_id
and
link.mem_seq=snd.mem_seq
where snd.msg_cd='0';
--for creating fact table used user_id from bz_send_log_filter_data_maxdt2 and camp_con_row_id from camp_final_17
-- gcrm.fact_camp_events which conatins all campaign details camp_con_row_id
--gcrm.camp_final_17 contains contact id ,camp_id and 
create table gcrm.fact_camp_events_log2
as
select a.* ,c.send_dt,c.click_dt,c.open_dt from gcrm.fact_camp_events as a 
left outer join gcrm.camp_final_17 as b 
on b.per_id=a.contact_id
left outer join gcrm.bz_send_log_filter_data_maxdt2 as c
on trim(c.user_id)= trim(b.camp_con_row_id)
where date(c.send_dt) between date(a.prog_start_dt_new) and date(a.prog_end_dt_new);--23,523,217


select * from gcrm.camp_final_17;


