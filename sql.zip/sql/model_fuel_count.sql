12,534,759     12,321,503; 12,266,232
drop table gcrm.fact_table_RO_4_suresh;
commit;
create table gcrm.fact_table_RO_4_suresh
as
select
	distinct 
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.asset_id,
	mi.camp_name,
	mi.channel_name,
	mi.prog_start_dt,
	mi.prog_end_dt,
	count(up1.repm_ro_no) as ro_count,
	(case
		when count(up1.repm_ro_no) > 0 then '1'
		when count(up1.repm_ro_no) = 0 then '0'
	end ) as bin_ro,
	sum( up1.Total_RO_amt) as total_ro_amt
	 from
	fact_table_RO_2 as mi
left outer join ndms.rcrepm_tb_dedup_3 as up1 on
	mi.vin = up1.repm_vin
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt
group by
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.channel_name,
	mi.asset_id,
	mi.camp_name,
	mi.prog_start_dt,
	mi.prog_end_dt	
  ;
  
select * from fact_table_RO_4_suresh
where vin='MALC841DLHM015226';
create table gcrm.fact_table_SMS_RO_3_suresh  as
select
	distinct 
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.asset_id,
	mi.camp_name,
	mi.channel_name,
	mi.prog_start_dt,
	mi.prog_end_dt,
	count(up1.repm_ro_no) as ro_count,
	(case
		when count(up1.repm_ro_no) > 0 then '1'
		when count(up1.repm_ro_no) = 0 then '0'
	end ) as bin_ro,
	 sum(up1.Total_RO_amt)
	 from
	fact_table_SMS_RO_2 as mi
left outer join ndms.rcrepm_tb_dedup_3 as up1 on
	 up1.repm_vin = mi.vin
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt
group by
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.channel_name,
	mi.asset_id,
	mi.camp_name,
	mi.prog_start_dt,
	mi.prog_end_dt;
	
vacuum full fact_table_SMS_RO_2;
vacuum full ndms.rcrepm_tb_dedup_3;
create table fuel_model_cout
as
select rvu.*,s.fuel_cd,s.model_cd,s.registered_dt from gcrm.ro_value_unique as rvu
left outer join s_asset as s
on s.asset_num= rvu.vin;--9723419

select count(*) from ro_value_unique;
vacuum full fuel_model_cout;

select * from fuel_model_cout;
select distinct fuel_cd, camp_name,count(*)  from fuel_model_cout
where bin_ro ='1'
group by fuel_cd,camp_name
;
create table vehl_age_count
as
select ((date(current_date)- prog_start_dt)/365) as dt_age,
(case when ((date(current_date) - date (registered_dt))/365)<=3 then  'GOLD'
        when ((date(current_date) - date (registered_dt))/365)>=4 and ((date(current_date) - date (registered_dt))/365)<=5  then 'PLATINUM'
        when ((date(current_date) - date (registered_dt))/365)>5 then 'LOYAL'
        end) as bin_age
        from fuel_model_cout ;

select count(*),bin_age from vehl_age_count
group by bin_age;

9849382061