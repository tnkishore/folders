------------------------------------Creating Dimensionwise table -----------------------------------
-- Create Contact Master Table for EDA data creation
-- Tables Used S_Contact, S_Per_Comm_addr 
-----------------------------------------------------------------------------------------------------------


-- 22,957,844

create table gcrm.contact_master as 
select distinct per_id as contact_id
from gcrm.s_per_comm_addr;

create table gcrm.contact_master_0 as 
select distinct row_id as contact_id
from gcrm.s_contact;

-- Checks 4,418,603
select count(*) 
from gcrm.s_contact as a 
where row_id not in ( select per_id from gcrm.contact_master_0);

insert into gcrm.contact_master select * from gcrm.contact_master_0;

-- 27,376,447
create table gcrm.contact_master_1 as
select distinct * from gcrm.contact_master;


--22,449,017

create table gcrm.contact_master_2a 
as select distinct per_id as contact_id , addr as Phone_num 
from gcrm.s_per_comm_addr as a 
where a.comm_medium_cd = 'Phone';

-- 27,274,227
create table gcrm.contact_master_2b 
as select distinct row_id as contact_id , cell_ph_num as Phone_num 
from gcrm.s_contact as a;

-- 49,723,24
insert into gcrm.contact_master_2a select * from gcrm.contact_master_2b;

SELECT COUNT(*) FROM gcrm.contact_master_2a ;

         
-- 30,477,571
create table gcrm.contact_master_2 as
select distinct * from gcrm.contact_master_2a;


--29,135,167
create table gcrm.contact_master_2f as 
select * from gcrm.contact_master_2
where Phone_num  is not null;


--15830002
create table gcrm.contact_master_3a 
as select distinct per_id, addr as Email_id
from gcrm.s_per_comm_addr as a	where a.comm_medium_cd = 'Email';

---- 27,274,227
create table gcrm.contact_master_3b 
as select distinct row_id as contact_id , email_addr as Email_id 
from gcrm.s_contact as a;

insert into gcrm.contact_master_3a select * from gcrm.contact_master_3b;

-- 29,326,828
create table gcrm.contact_master_3 as
select distinct * from gcrm.contact_master_3a;

--22,957,844
create table gcrm.contact_master_4a
as select distinct per_id, a.name as last_name
from gcrm.s_per_comm_addr as a;

create table gcrm.contact_master_4b 
as select distinct row_id as contact_id , last_name
from gcrm.s_contact as a;

insert into gcrm.contact_master_4a select * from gcrm.contact_master_4b;

-- 50232071
create table gcrm.contact_master_4 as
select distinct * from gcrm.contact_master_4a;

-- 28,352,579
create table gcrm.contact_master_5 as 
select distinct a.*, b.Phone_num , c.Email_id, d.last_name
from gcrm.contact_master_1 as a
left outer join gcrm.contact_master_2 as b on  a.contact_id = b.contact_id 
left outer join gcrm.contact_master_3 as c on  a.contact_id = b.contact_id 
left outer join gcrm.contact_master_4 as d on  a.contact_id  = c.contact_id ;










