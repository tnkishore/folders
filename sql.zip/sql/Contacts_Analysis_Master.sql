------------------------------------Creating Dimensionwise table -----------------------------------
-- Create Contact Analysis Master Table
-- Tables Used S_Contact, S_Per_Comm_addr, S_addr_per, lookups from Anurag for City to State, Region, Zone mapping
-----------------------------------------------------------------------------------------------------------
-- 2 milllion
select count(*), count(distinct a.contact_id) 
from gcrm.contact_analysis_master as a 
where PR_PER_ADDR_ID not in ( select distinct row_id from gcrm.s_addr_per);


create table gcrm.contact_analysis_master as 
select distinct a.row_id as contact_id , CON_CD, PER_TITLE , PR_PER_ADDR_ID, SEX_MF
from gcrm.s_contact as a;


-- 27,274,227 
CREATE TABLE gcrm.contact_analysis_master_1 AS
SELECT A.*, B.CITY
FROM gcrm.contact_analysis_master A 
LEFT OUTER JOIN gcrm.s_addr_per B ON A.PR_PER_ADDR_ID = b.row_id ;                                     


create table city_mapping_final
(City_Code	varchar(20),City varchar(20),State varchar(20),Region varchar(20),zone varchar(20)
);

create table Dealer_mapping_final
(Dealer_Code	varchar(20),State_New varchar(20),Region varchar(20),zone varchar(20)
);

create table gcrm.contact_analysis_master_2 as
select a.*, b.city as con_city_name, b.state as con_state, b.region as con_region , b.zone as con_zone
from gcrm.contact_analysis_master_1 as a 
 left outer join  gcrm.city_mapping_final b on a.city = b.city_code;

select * from contact_analysis_master_2;



