--------------------------------------------------------------------------------------
---- Creating the Fact table - RO count and value for 47 SMS Campaigns --------------------------
-------------------------------------------------------------------------------------------
---count 47,478,842
create table gcrm.fact_table_SMS_RO_1  as
select * from gcrm.sms_contacts_4
where per_id not in ( select * from ndms.ocmv_exclutionlist);

drop table gcrm.fact_table_SMS_RO_2;
commit;
-----count ---count 46,511,469 --sms_filename  
create table gcrm.fact_table_SMS_RO_2
as
select distinct 
	sc.sms_campaign_name as camp_name,
	sc.sms_filename,
	sc.sms_year,
	sc.sms_month,
	sc.asset_id,
	veh.asset_num as vin,
	sc.sms_mobile,
	sc.per_id as contact_id,
	sm1.camp_id,
	sm1.prog_start_dt,
	sm1.prog_end_dt,
	(case
		when sm1.prog_start_dt is not null then 'SMS'
	end )as channel_name
from
	fact_table_SMS_RO_1 as sc
left outer join sms_comb_file_names as sm1 on
	sm1.sms_campaign_name = sc.sms_campaign_name
	--sm1.combinedv3_smscamp_name = sc.sms_filename
	and sm1.sms_year = sc.sms_year
	and sm1.sms_month = sc.sms_month
left outer join s_asset as veh on
	veh.row_id = sc.asset_id;
	
	drop table fact_table_SMS_RO_3;
commit;
--44408491	
create table gcrm.fact_table_SMS_RO_3  as
select
	distinct 
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.asset_id,
	mi.camp_name,
	mi.channel_name,
	mi.prog_start_dt,
	mi.prog_end_dt,
	up1.repm_dlr_no,
	count(up1.repm_ro_no) as ro_count,
	(case
		when count(up1.repm_ro_no) > 0 then '1'
		when count(up1.repm_ro_no) = 0 then '0'
	end ) as bin_ro,
	 up1.Total_RO_amt
	 from
	fact_table_SMS_RO_2 as mi
left outer join ndms.rcrepm_tb_dedup_3 as up1 on
	 up1.repm_vin = mi.vin
	and date(up1.repm_ro_dtime) between mi.prog_start_dt and mi.prog_end_dt
group by
	mi.camp_id,
	mi.contact_id,
	mi.vin,
	mi.channel_name,
	mi.asset_id,
	mi.camp_name,
	mi.prog_start_dt,
	mi.prog_end_dt,
	up1.repm_dlr_no,
   up1.Total_RO_amt;

 --count 44408491 
  create table  gcrm.full_fact_table_RO
  as select * from gcrm.fact_table_SMS_RO_3;
 --count 12534759 
 insert into gcrm.full_fact_table_RO
 select * from gcrm.fact_table_RO_3;
 
--total fact table count 56,943,250
select count(*) from full_fact_table_RO;

select * from full_fact_table_RO where repm_dlr_no is not null and channel_name='EMAIL';
select sum((bin_ro))  from full_fact_table_RO
group by 1; --count 56943250