--creating table with campaign details with campaign_type='EW Promotion'
CREATE TABLE gcrm.all_three4_ew (
              new_camp_id varchar(20) NULL,
              new_campaign_disp_name varchar(100) NULL,
              contact_id varchar(15) NULL,
              asset_id varchar(15) NULL,
              vin varchar(100) NULL,
              prog_start_dt_new timestamp NULL,
              prog_end_dt_new timestamp NULL,
              channel_clubbed varchar(20) NULL,
              campaign_type varchar(20) NULL
);

---total count 1,010,964
select count(*) from gcrm.all_three4_ew ;
--creating  table with extended warnty three years data with matching vin number from campaign table and warnty table 
-----count 1010966
create table  gcrm.all_three4_ew_extended_warnty
as
select
     distinct 
	a.new_camp_id,
	a.new_campaign_disp_name,
	a.contact_id,
	a.asset_id,
	a.vin,
	a.channel_clubbed,
	a.campaign_type,
	date(a.prog_start_dt_new) as prog_start_dt_new,
	date(a.prog_end_dt_new) as prog_end_dt_new,
	date(b.extb_reg_date) as extb_reg_date,
	b.extb_wrnty_no,
	b.extb_dlr_no,
	b.extb_wrnty_amt,
	b.extb_odom_val
	from  gcrm.all_three4_ew
	 as a
left outer join gcrm.extended_warranty_threeyears_data as b on
	b.extb_vin = a.vin
and
	date(b.extb_reg_date) between date(a.prog_start_dt_new) and date(a.prog_end_dt_new);
---for avoiding duplicates at wanty amnt and delar level fetching records with Maximum warnty amount
--count 1010964
drop table all_three4_ew_extended_warnty_maxodomtr;
commit;
create table gcrm.all_three4_ew_extended_warnty_maxodomtr
as 
select distinct 
	new_camp_id,
	contact_id,
	vin,max(extb_wrnty_amt) as extb_wrnty_amt,
	count(extb_wrnty_no) as wrnty_no_cnt,extb_dlr_no,
	(case when count(extb_wrnty_no) >0 then 1
	      else 0
	      end) as extb_bin,
	max (extb_odom_val) as max_extb_odom_val
	from gcrm.all_three4_ew_extended_warnty
	group by new_camp_id,
	contact_id,
	vin ,extb_dlr_no;
	
	drop table all_three4_ew_extended_warnty1;
commit;

--final factable creation with using maximum odometer vallue and maximum warnty amount 
----  contacted customers count=1010964
create table  gcrm.all_three4_ew_extended_warnty1
as
select distinct
	a.new_camp_id,
	a.new_campaign_disp_name,
	a.contact_id,
	a.asset_id,
	a.vin,
	a.channel_clubbed,
	a.campaign_type,
	a.prog_start_dt_new,
	a.prog_end_dt_new,
	b.extb_wrnty_amt,
	b.wrnty_no_cnt,b.extb_bin,
	a.extb_dlr_no,
	b.max_extb_odom_val
	from gcrm.all_three4_ew_extended_warnty as a 
left join gcrm.all_three4_ew_extended_warnty_maxodomtr as b 
	on  b.vin= a.vin and
	a.new_camp_id=b.new_camp_id and
	a.contact_id=b.contact_id
	and b.max_extb_odom_val = a.extb_odom_val
	and b.extb_wrnty_amt = a.extb_wrnty_amt
	;
--checks
--count always shuld be zero
select count(*) from  (
select new_camp_id, contact_id,vin, count(*) from gcrm.all_three4_ew_extended_warnty1
group by 1,2,3
having count(*) >1 ) as b;






