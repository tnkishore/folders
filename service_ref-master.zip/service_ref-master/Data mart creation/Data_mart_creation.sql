--1) Remove taxi customers from Referral table (crm_rcrfl_tb) and create a separate table in Referral Data Mart (REFRL_MART)
delete from "REFRL_MART".crm_rcrefl_tb where refl_vin in 
(select distinct (a.refl_vin) 
from  "REFRL_MART".crm_rcrefl_tb a, gcrm.s_asset b, gcrm.s_vhcl_sales c 
where a.refl_vin = b.asset_num 
and b.row_id = c.vhcl_id  
and c.ownr_cd in ('Rent-a-car Fleet', 'Taxi', 'Taxi Fleet')) 
--Additionally, got a list of VINs from CRM team that includes prime car. Those VINs were also removed from the above table. This was done in python and codes provided seprately

--2) Create service table for Referral Data Mart
--A)Fetch service data from 2016-11-29 onwards but not the referral VINs. 
insert into "REFRL_MART".refrl_ser_rcrepm_tb 
SELECT * FROM ndms.ser_rcrepm_tb 
where repm_vin in (
select repm_vin from ndms.ser_rcrepm_tb 
where  repm_ro_dtime >= '2016-11-29') 
where repm_vin  not in ( 
select refl_vin from "REFRL_MART".crm_rcrefl_tb) 
and repm_ro_dtime > '2009-01-01'; 
--B) Insert service data for the referral VINs. 
insert into "REFRL_MART".refrl_ser_rcrepm_tb 
SELECT * FROM ndms.ser_rcrepm_tb
where repm_vin in (
select refl_vin from "REFRL_MART".crm_rcrefl_tb)

--3) Fetch cust details and phone numbers using dlr_code and cust_no from service table. These phone numbers are service phone number
CREATE TABLE "REFRL_MART".cust_details AS  
select distinct(concat(a.repm_dlr_no, a.repm_cust_no)) as cust_id,  
a.repm_dlr_no, a.repm_cust_no, a.repm_vin, b.csph_cust_phone_no, c.con_id, c.person_uid, 
d.age, d.annl_incm_amt, d.birth_dt, d.credit_score, d.job_title, d.occupation, c.sex_mf,  
d.marital_stat_cd, c.state, c.title, c.con_type, d.cell_ph_num as contact_cell_phone, c.cell_ph_num as master_cell_phone 
from "REFRL_MART".refrl_ser_rcrepm_tb a 
left join ndms.crm_cdcsph_tb b on a.repm_dlr_code = b.csph_dlr_code and a.repm_cust_no = b.csph_cust_no 
left join gcrm.cx_cust_master c on a.repm_dlr_code = c.gdms_dlr_id and a.repm_cust_no = c.gdms_cust_id 
join gcrm.s_contact d on d.row_id = c.con_id 

--4) extract phone numbers for all VINs present in rferral data Mart
create table "REFRL_MART".refrl_vhcl_history_vin as 
select a.vhcl_id, a.sale_dt, a.dlr_ou_id, b.repm_vin, a.con_id as vhcl_con_id 
from gcrm.s_vhcl_sales a, "REFRL_MART".rfrl_ser_rcrepm_tb b, gcrm.s_asset c 
where b.repm_vin = c.asset_num 
and a.vhcl_id = c.row_id; 
alter table "REFRL_MART".refrl_vhcl_history_vin 
add column phone_no varchar(22);  
update "REFRL_MART".refrl_vhcl_history_vin 
set phone_no = a.cell_ph_num 
from gcrm.cx_cust_master a 
where "REFRL_MART".refrl_vhcl_history_vin.vhcl_con_id = a.row_id

--5) Find VINs that have used tag
select a.vinm_vin, a.vinm_selling_date, b.repm_dlr_code, b.repm_dlr_no, 
b.repm_cust_no, b.repm_ro_dtime
from ndms.cmm_cavinm_tb a, "REFRL_MART".refrl_ser_rcrepm_tb b 
where a.csvm_vin = b.repm_vin
and a.vinm_used_stat='30'

--Service phone and VINs were mapped using python. Codes provided separately